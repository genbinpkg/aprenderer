#!/bin/bash
cd /usr/aprenderer
sudo ./ap2renderer
